package tcpclient;
import java.net.*;
import java.io.*;

public class TCPClient {
    
    public TCPClient(boolean shutdown, Integer timeout, Integer limit) {
    }

    public byte[] askServer(String hostname, int port, byte [] toServerBytes) throws IOException {
        return new byte[0];
    }
}
